﻿import pandas as pd
import plotly.graph_objects as go
from pathlib import Path

# Load results
results_dir = Path('results/tables')
df = pd.read_csv(results_dir / 'table1_model_comparison.csv')

# Create comparison chart
fig = go.Figure()

metrics = ['Recall@3', 'MRR', 'EM', 'F1', 'ROUGE-L']
for metric in metrics:
    fig.add_trace(go.Bar(
        name=metric,
        x=df['Model'],
        y=df[metric].astype(float)
    ))

fig.update_layout(
    title='Model Performance Comparison',
    xaxis_title='Model',
    yaxis_title='Score',
    barmode='group'
)

fig.write_html(results_dir / 'performance_chart.html')
print(' Chart saved: results/tables/performance_chart.html')
