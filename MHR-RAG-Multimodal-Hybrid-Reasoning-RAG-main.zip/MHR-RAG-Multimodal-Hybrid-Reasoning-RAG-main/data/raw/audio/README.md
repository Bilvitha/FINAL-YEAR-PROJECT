﻿# Audio Files Directory

Place your audio files here for transcription and processing.

## Supported Formats
- MP3
- WAV
- M4A
- OGG
- FLAC
- AAC

## File Requirements
- Maximum size: 25 MB per file (larger files automatically split)
- Language: English (primary), auto-detection for others
- Quality: Clear audio recommended for best transcription

## Usage
1. Upload via Streamlit UI (Audio Processing tab)
2. Or place files directly in this folder
3. System will transcribe with timestamps
4. Queries support temporal format: "At 5:30, what was discussed?"

## Example Sources
- Educational lectures
- Podcasts
- Conference presentations
- Interview recordings
