﻿# PDF Documents Directory

Place your PDF files here for processing.

## Supported Content
- Research papers
- Technical documentation
- Textbooks
- Reports with tables and figures

## File Requirements
- Format: PDF
- No size limit (system handles large files)
- Can contain text, tables, and images

## Usage
1. Upload via Streamlit UI (Document Ingestion tab)
2. Or place files directly in this folder
3. Run: python run_pipeline.py

## Example Files
Sample research papers are available at:
- https://arxiv.org/abs/1706.03762 (Attention Is All You Need)
- https://arxiv.org/abs/2502.08826 (Multimodal RAG Survey)
