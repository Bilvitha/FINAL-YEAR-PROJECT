﻿# MHR-RAG: Multimodal Hybrid Reasoning RAG

Multimodal Retrieval-Augmented Generation system with efficient multilingual output.

## Features
-  Multimodal: Text, Tables, Images, Audio
-  Multilingual: 5 Indian Languages + English
-  Free-tier APIs: Groq + Local Embeddings
-  Zero-cost deployment

## Setup

### 1. Install Dependencies
\\\powershell
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
\\\

### 2. Configure API Keys
Edit \.env\ file with your keys

### 3. Run Streamlit UI
\\\powershell
streamlit run app.py
\\\

### 4. Or Run Batch Pipeline
\\\powershell
python run_pipeline.py
\\\

## Usage

### Via UI
1. Upload PDF in 'Document Ingestion' tab
2. Click 'Process Document'
3. Go to 'Query & Retrieve' tab
4. Enter question and select language
5. Get multilingual answers with sources

### Via Script
1. Place PDFs in \data/raw/pdfs/\
2. Run: \python run_pipeline.py\
3. Query: \python -c \"from src.retrieval.query_rag import query_rag; print(query_rag('your question'))\"\

## System Architecture

\\\
Document  Partition  Chunk  Summarize  Embed  Index (ChromaDB)
                                                          
User Query  Embed  Retrieve  Generate (Groq)  Translate  Answer
\\\

## Models Used
- **LLMs**: gemma2-9b-it, llama3-8b/70b-8192, llama-3.1-8b-instant
- **Embeddings**: sentence-transformers/all-MiniLM-L6-v2
- **ASR**: whisper-large-v3
- **Vision**: BLIP-2 (optional)

## License
MIT
