﻿import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # API Keys
    HF_API_TOKEN = os.getenv('HF_API_TOKEN')
    GROQ_API_KEY = os.getenv('GROQ_API_KEY')
    
    # Paths
    CHROMA_PERSIST_DIR = os.getenv('CHROMA_PERSIST_DIR', './dbv1/chroma_db')
    DATA_RAW_DIR = os.getenv('DATA_RAW_DIR', './data/raw')
    DATA_PROCESSED_DIR = os.getenv('DATA_PROCESSED_DIR', './data/processed')
    RESULTS_DIR = os.getenv('RESULTS_DIR', './results')
    
    # Models - UPDATED FOR OCTOBER 2025
    EMBEDDING_MODEL = os.getenv('EMBEDDING_MODEL', 'sentence-transformers/all-MiniLM-L6-v2')
    DEFAULT_LLM = os.getenv('DEFAULT_LLM', 'llama-3.3-70b-versatile')
    SUMMARIZATION_MODEL = os.getenv('SUMMARIZATION_MODEL', 'llama-3.1-8b-instant')
    TRANSLATION_MODEL = os.getenv('TRANSLATION_MODEL', 'llama-3.3-70b-versatile')
    WHISPER_MODEL = os.getenv('WHISPER_MODEL', 'whisper-large-v3')
    
    # Available Models (Current as of October 2025)
    AVAILABLE_LLMS = [
        'llama-3.1-8b-instant',
        'llama-3.3-70b-versatile',
        'openai/gpt-oss-120b',
        'meta-llama/llama-4-scout-17b-16e-instruct',
        'qwen/qwen3-32b'
    ]
    
    # ALL 22 OFFICIAL INDIAN LANGUAGES (Constitution Schedule VIII)
    SUPPORTED_LANGUAGES = {
        'English': 'en',
        'Hindi / हनद': 'hi',
        'Bengali / বল': 'bn',
        'Telugu / తలగ': 'te',
        'Marathi / मरठ': 'mr',
        'Tamil / தமழ': 'ta',
        'Gujarati / ગજરત': 'gu',
        'Urdu / اردو': 'ur',
        'Kannada / ಕನನಡ': 'kn',
        'Odia / ଓଡଆ': 'or',
        'Malayalam / മലയള': 'ml',
        'Punjabi / ਪਜਬ': 'pa',
        'Assamese / অসময': 'as',
        'Maithili / मथल': 'mai',
        'Santali / ᱥᱟᱱᱛᱟᱲᱤ': 'sat',
        'Kashmiri / کٲشر': 'ks',
        'Nepali / नपल': 'ne',
        'Konkani / ककण': 'kok',
        'Sindhi / سنڌي': 'sd',
        'Dogri / डगर': 'doi',
        'Manipuri / ': 'mni',
        'Bodo / बड': 'brx',
        'Sanskrit / ससकतम': 'sa'
    }
    
    # Audio file formats supported
    SUPPORTED_AUDIO_FORMATS = ['.mp3', '.wav', '.m4a', '.ogg', '.flac', '.aac']
    
    # Processing Settings
    MAX_CHUNK_SIZE = 3000
    NEW_CHUNK_AFTER = 2400
    COMBINE_UNDER = 500
    TOP_K_RETRIEVAL = 5
