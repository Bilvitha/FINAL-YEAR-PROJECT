﻿from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from src.utils.config import Config
from groq import Groq

# Initialize
embedding_model = SentenceTransformer(Config.EMBEDDING_MODEL)
groq_client = Groq(api_key=Config.GROQ_API_KEY)

def query_rag(query: str, model_name: str = None, top_k: int = 5):
    '''Complete RAG pipeline'''
    
    if model_name is None:
        model_name = Config.DEFAULT_LLM
    
    # 1. Embed query
    query_embedding = embedding_model.encode([query])[0]
    
    # 2. Retrieve from ChromaDB
    client = chromadb.PersistentClient(
        path=Config.CHROMA_PERSIST_DIR,
        settings=Settings(anonymized_telemetry=False)
    )
    
    collection = client.get_collection('mhr_rag_collection')
    
    results = collection.query(
        query_embeddings=[query_embedding.tolist()],
        n_results=top_k
    )
    
    # 3. Build context
    contexts = []
    for i, (metadata, distance) in enumerate(zip(results['metadatas'][0], results['distances'][0])):
        similarity_score = 1 - distance
        context_block = f'''[{i+1}] Source: {metadata['source_file']}, Chunk: {metadata['chunk_id']}, Score: {similarity_score:.3f}
Short Summary: {metadata['short_summary']}
Full Context: {metadata['long_summary']}
Modalities: {metadata['modality_types']}
Tables: {metadata['tables_count']}, Images: {metadata['image_count']}
'''
        contexts.append(context_block)
    
    # 4. Generate answer
    prompt = f'''You are an expert research assistant. Answer the question using ONLY the provided contexts.

QUESTION: {query}

CONTEXTS:
{''.join(contexts)}

INSTRUCTIONS:
1. Answer concisely using ONLY the contexts above
2. Cite sources as [1], [2], [3] in your answer
3. If contexts don't contain sufficient information, say so
4. Focus on accuracy over completeness

ANSWER:'''
    
    response = groq_client.chat.completions.create(
        model=model_name,
        messages=[
            {'role': 'system', 'content': 'You are a helpful research assistant.'},
            {'role': 'user', 'content': prompt}
        ],
        temperature=0.2,
        max_tokens=512
    )
    
    answer = response.choices[0].message.content
    
    return {
        'answer': answer,
        'model': model_name,
        'contexts': contexts,
        'retrieved_metadata': results['metadatas'][0]
    }
