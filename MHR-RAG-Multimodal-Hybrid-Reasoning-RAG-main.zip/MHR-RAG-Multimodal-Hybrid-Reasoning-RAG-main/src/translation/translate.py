﻿from groq import Groq
from src.utils.config import Config

groq_client = Groq(api_key=Config.GROQ_API_KEY)

def translate_answer(english_answer: str, target_language: str) -> str:
    '''Translate final answer to Indian languages'''
    
    if target_language.lower() == 'english' or target_language == 'en':
        return english_answer
    
    # Get full language name
    lang_map = {v: k for k, v in Config.SUPPORTED_LANGUAGES.items()}
    full_lang_name = lang_map.get(target_language, target_language)
    
    translation_prompt = f'''Translate the following English text to {full_lang_name}.

IMPORTANT PRESERVATION RULES:
1. Keep all citations [1], [2], [3] exactly as they are
2. Keep technical terms in English (e.g., "Transformer", "attention mechanism")
3. Keep all numbers and units unchanged
4. Preserve paragraph formatting

English Text:
{english_answer}

{full_lang_name} Translation:'''
    
    response = groq_client.chat.completions.create(
        model=Config.TRANSLATION_MODEL,
        messages=[
            {'role': 'system', 'content': 'You are an expert translator specializing in Indian languages.'},
            {'role': 'user', 'content': translation_prompt}
        ],
        temperature=0.2,
        max_tokens=1024
    )
    
    return response.choices[0].message.content
