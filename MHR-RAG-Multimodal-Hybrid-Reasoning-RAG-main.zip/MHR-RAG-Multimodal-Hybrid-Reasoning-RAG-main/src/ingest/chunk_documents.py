﻿from typing import List, Dict

def create_chunks_by_title(elements: List[Dict], max_chars: int = 3000) -> List[Dict]:
    '''Simple text chunking without unstructured dependency'''
    print(' Creating chunks...')
    
    chunks = []
    current_chunk = ''
    current_pages = []
    
    for element in elements:
        text = element.get('text', '')
        page = element.get('page', 0)
        
        # If adding this text exceeds max_chars, save current chunk
        if len(current_chunk) + len(text) > max_chars and current_chunk:
            chunks.append({
                'text': current_chunk,
                'pages': list(set(current_pages)),
                'metadata': {'orig_elements': []}
            })
            current_chunk = ''
            current_pages = []
        
        current_chunk += text + '\n\n'
        current_pages.append(page)
    
    # Add final chunk
    if current_chunk:
        chunks.append({
            'text': current_chunk,
            'pages': list(set(current_pages)),
            'metadata': {'orig_elements': []}
        })
    
    print(f' Created {len(chunks)} chunks')
    return chunks
