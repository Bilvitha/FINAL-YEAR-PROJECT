﻿import pdfplumber
from typing import List, Dict

def partition_document(file_path: str) -> List[Dict]:
    '''Extract elements from PDF using pdfplumber (lighter alternative)'''
    print(f' Partitioning document: {file_path}')
    
    elements = []
    
    with pdfplumber.open(file_path) as pdf:
        for page_num, page in enumerate(pdf.pages):
            # Extract text
            text = page.extract_text()
            if text:
                elements.append({
                    'type': 'text',
                    'text': text,
                    'page': page_num + 1
                })
            
            # Extract tables
            tables = page.extract_tables()
            for table in tables:
                elements.append({
                    'type': 'table',
                    'text': str(table),
                    'page': page_num + 1
                })
    
    print(f' Extracted {len(elements)} elements')
    return elements

def separate_content_types(chunk):
    '''Simplified content separation'''
    return {
        'text': chunk.get('text', ''),
        'tables': [],
        'images': [],
        'types': ['text']
    }
