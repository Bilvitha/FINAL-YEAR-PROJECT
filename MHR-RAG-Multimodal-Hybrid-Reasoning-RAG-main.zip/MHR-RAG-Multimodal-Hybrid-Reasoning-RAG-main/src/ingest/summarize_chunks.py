﻿from groq import Groq
from src.utils.config import Config
from src.ingest.partition_document import separate_content_types
import json

groq_client = Groq(api_key=Config.GROQ_API_KEY)

def create_summary(text: str, tables: list, images: list) -> tuple:
    '''Create dual summaries: short (for embedding) and long (for context)'''
    
    # Build prompt
    prompt_text = f'''Analyze this document content and create two summaries:

CONTENT:
{text}

'''
    
    if tables:
        prompt_text += 'TABLES:\n'
        for i, table in enumerate(tables):
            prompt_text += f'Table {i+1}:\n{table[:500]}...\n\n'
    
    if images:
        prompt_text += f'IMAGES: {len(images)} diagrams/figures present\n\n'
    
    prompt_text += '''
Generate TWO summaries:

1. SHORT SUMMARY (50-150 tokens for embedding):
Focus on key topics and searchable keywords.

2. LONG SUMMARY (200-600 tokens for context):
Detailed description including:
- Main concepts and facts
- Table data and numbers
- Visual content descriptions
- Questions this content answers

Format as JSON:
{
  "short_summary": "...",
  "long_summary": "..."
}
'''
    
    try:
        response = groq_client.chat.completions.create(
            model=Config.SUMMARIZATION_MODEL,
            messages=[
                {'role': 'system', 'content': 'You are an expert document summarizer.'},
                {'role': 'user', 'content': prompt_text}
            ],
            temperature=0.3,
            max_tokens=800
        )
        
        # Parse JSON response
        result = json.loads(response.choices[0].message.content)
        return result['short_summary'], result['long_summary']
        
    except Exception as e:
        print(f' Summarization failed: {e}')
        # Fallback
        short = text[:150]
        long = text[:600]
        return short, long

def summarize_chunks(chunks):
    '''Process all chunks with summaries'''
    print(' Processing chunks with AI Summaries...')
    
    processed_chunks = []
    total = len(chunks)
    
    for i, chunk in enumerate(chunks):
        print(f'   Processing chunk {i+1}/{total}')
        
        # Analyze content
        content_data = separate_content_types(chunk)
        
        # Create summaries
        short_summary, long_summary = create_summary(
            content_data['text'],
            content_data['tables'],
            content_data['images']
        )
        
        # Create structured document
        doc_data = {
            'chunk_id': i,
            'short_summary': short_summary,
            'long_summary': long_summary,
            'raw_text': content_data['text'],
            'tables_html': content_data['tables'],
            'image_count': len(content_data['images']),
            'modality_types': content_data['types']
        }
        
        processed_chunks.append(doc_data)
    
    print(f' Processed {len(processed_chunks)} chunks')
    return processed_chunks
