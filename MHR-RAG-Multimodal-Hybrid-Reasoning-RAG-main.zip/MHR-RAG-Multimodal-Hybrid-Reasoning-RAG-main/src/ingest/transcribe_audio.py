﻿from groq import Groq
from src.utils.config import Config
from pydub import AudioSegment
import os

groq_client = Groq(api_key=Config.GROQ_API_KEY)

def transcribe_audio_file(audio_path: str) -> dict:
    '''Transcribe audio file using Groq Whisper API with timestamps'''
    print(f' Transcribing audio: {audio_path}')
    
    # Check file format
    file_ext = os.path.splitext(audio_path)[1].lower()
    if file_ext not in Config.SUPPORTED_AUDIO_FORMATS:
        raise ValueError(f'Unsupported audio format: {file_ext}')
    
    # If file is too large, split it
    max_size_mb = 25  # Groq's limit
    file_size_mb = os.path.getsize(audio_path) / (1024 * 1024)
    
    if file_size_mb > max_size_mb:
        print(f'   Audio file is {file_size_mb:.1f}MB, splitting...')
        segments = split_audio(audio_path, max_size_mb)
    else:
        segments = [audio_path]
    
    # Transcribe all segments
    full_transcription = []
    cumulative_time = 0
    
    for i, segment_path in enumerate(segments):
        print(f'   Transcribing segment {i+1}/{len(segments)}...')
        
        with open(segment_path, 'rb') as audio_file:
            response = groq_client.audio.transcriptions.create(
                file=audio_file,
                model=Config.WHISPER_MODEL,
                response_format='verbose_json',  # Get timestamps
                language='en'  # Auto-detect if None
            )
        
        # Process segments with timestamps
        if hasattr(response, 'segments'):
            for seg in response.segments:
                full_transcription.append({
                    'start': seg['start'] + cumulative_time,
                    'end': seg['end'] + cumulative_time,
                    'text': seg['text']
                })
        else:
            # Fallback if no segments
            full_transcription.append({
                'start': cumulative_time,
                'end': cumulative_time + 30,  # Estimate
                'text': response.text
            })
        
        # Update cumulative time
        if segments[i] != audio_path:
            audio = AudioSegment.from_file(segment_path)
            cumulative_time += len(audio) / 1000  # Convert ms to seconds
            os.remove(segment_path)  # Clean up temp file
    
    print(f' Transcribed {len(full_transcription)} segments')
    
    return {
        'source_file': os.path.basename(audio_path),
        'duration': cumulative_time,
        'segments': full_transcription,
        'full_text': ' '.join([s['text'] for s in full_transcription])
    }

def split_audio(audio_path: str, max_size_mb: int) -> list:
    '''Split large audio file into smaller chunks'''
    audio = AudioSegment.from_file(audio_path)
    duration_ms = len(audio)
    
    # Calculate chunk size in milliseconds
    file_size_mb = os.path.getsize(audio_path) / (1024 * 1024)
    num_chunks = int(file_size_mb / max_size_mb) + 1
    chunk_duration_ms = duration_ms // num_chunks
    
    chunks = []
    temp_dir = os.path.join(Config.DATA_PROCESSED_DIR, 'temp_audio')
    os.makedirs(temp_dir, exist_ok=True)
    
    for i in range(num_chunks):
        start_ms = i * chunk_duration_ms
        end_ms = min((i + 1) * chunk_duration_ms, duration_ms)
        
        chunk = audio[start_ms:end_ms]
        chunk_path = os.path.join(temp_dir, f'chunk_{i}.mp3')
        chunk.export(chunk_path, format='mp3')
        chunks.append(chunk_path)
    
    return chunks

def format_timestamp(seconds: float) -> str:
    '''Format seconds to MM:SS format'''
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    return f'{minutes:02d}:{secs:02d}'
