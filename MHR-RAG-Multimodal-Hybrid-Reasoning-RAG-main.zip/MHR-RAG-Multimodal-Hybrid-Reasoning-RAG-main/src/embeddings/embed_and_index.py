﻿from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from src.utils.config import Config
import json

# Initialize embedding model
print(f'Loading embedding model: {Config.EMBEDDING_MODEL}')
embedding_model = SentenceTransformer(Config.EMBEDDING_MODEL)

def embed_chunks(processed_chunks):
    '''Generate embeddings for all chunks'''
    print(' Creating embeddings...')
    
    # Extract short summaries for embedding
    texts = [chunk['short_summary'] for chunk in processed_chunks]
    
    # Generate embeddings
    embeddings = embedding_model.encode(texts, show_progress_bar=True)
    
    print(f' Generated {len(embeddings)} embeddings')
    return embeddings

def create_vector_store(processed_chunks, embeddings, source_file):
    '''Create ChromaDB vector store'''
    print(f' Indexing into ChromaDB...')
    
    # Initialize ChromaDB
    client = chromadb.PersistentClient(
        path=Config.CHROMA_PERSIST_DIR,
        settings=Settings(anonymized_telemetry=False)
    )
    
    # Get or create collection
    collection = client.get_or_create_collection(
        name='mhr_rag_collection',
        metadata={'hnsw:space': 'cosine'}
    )
    
    # Prepare data
    ids = [f'{source_file}:chunk_{i}' for i in range(len(processed_chunks))]
    
    metadatas = []
    for chunk in processed_chunks:
        metadata = {
            'source_file': source_file,
            'chunk_id': str(chunk['chunk_id']),
            'short_summary': chunk['short_summary'],
            'long_summary': chunk['long_summary'],
            'raw_text': chunk['raw_text'][:1000],  # Truncate for storage
            'tables_count': str(len(chunk['tables_html'])),
            'image_count': str(chunk['image_count']),
            'modality_types': ','.join(chunk['modality_types'])
        }
        metadatas.append(metadata)
    
    # Add to collection
    collection.add(
        ids=ids,
        embeddings=embeddings.tolist(),
        metadatas=metadatas
    )
    
    print(f' Indexed {len(ids)} chunks into ChromaDB')
    return collection
