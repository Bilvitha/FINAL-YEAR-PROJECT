import json
import time
import pandas as pd
import numpy as np
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.utils.config import Config
from src.retrieval.query_rag import query_rag
from src.translation.translate import translate_answer
from rouge_score import rouge_scorer
from collections import defaultdict
import re

class RAGEvaluator:
    def __init__(self):
        self.rouge_scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
        
    def evaluate_retrieval(self, retrieved_chunks, relevant_chunks):
        retrieved_ids = [chunk.split('Source: ')[1].split(',')[0] if 'Source:' in chunk else chunk 
                        for chunk in retrieved_chunks]
        
        recall_at_k = {}
        for k in [1, 3, 5]:
            top_k_ids = retrieved_ids[:k]
            relevant_found = sum(1 for rel in relevant_chunks if any(rel in ret for ret in top_k_ids))
            recall_at_k[f'recall@{k}'] = relevant_found / len(relevant_chunks) if relevant_chunks else 0
        
        mrr = 0
        for rel in relevant_chunks:
            for rank, ret in enumerate(retrieved_ids, 1):
                if rel in ret:
                    mrr = 1 / rank
                    break
        
        return {**recall_at_k, 'mrr': mrr}
    
    def evaluate_answer_quality(self, predicted, ground_truth):
        pred_norm = predicted.lower().strip()
        gold_norm = ground_truth.lower().strip()
        
        em = 1.0 if pred_norm == gold_norm else 0.0
        
        pred_tokens = set(pred_norm.split())
        gold_tokens = set(gold_norm.split())
        
        if not pred_tokens or not gold_tokens:
            f1 = 0.0
        else:
            common = pred_tokens & gold_tokens
            precision = len(common) / len(pred_tokens)
            recall = len(common) / len(gold_tokens)
            f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        
        rouge_scores = self.rouge_scorer.score(ground_truth, predicted)
        rouge_l = rouge_scores['rougeL'].fmeasure
        
        return {'exact_match': em, 'f1': f1, 'rouge_l': rouge_l}
    
    def evaluate_translation(self, original_text, translated_text):
        original_len = len(original_text.split())
        translated_len = len(translated_text.split())
        length_ratio = translated_len / original_len if original_len > 0 else 0
        
        citations_original = len(re.findall(r'\[\d+\]', original_text))
        citations_translated = len(re.findall(r'\[\d+\]', translated_text))
        citation_preservation = citations_translated / citations_original if citations_original > 0 else 1.0
        
        return {'length_ratio': length_ratio, 'citation_preservation': citation_preservation}
    
    def run_benchmark(self, queries_file, models_to_test, languages_to_test):
        with open(queries_file, 'r', encoding='utf-8-sig') as f:
            queries = json.load(f)
        
        print(f'\n{"="*60}')
        print(f'BENCHMARK: {len(queries)} queries x {len(models_to_test)} models x {len(languages_to_test)} languages')
        print(f'{"="*60}\n')
        
        all_results = []
        
        for model_name in models_to_test:
            print(f'\n--- Testing Model: {model_name} ---')
            
            model_results = {
                'model': model_name,
                'retrieval_metrics': defaultdict(list),
                'answer_metrics': defaultdict(list),
                'translation_metrics': defaultdict(lambda: defaultdict(list)),
                'latency': []
            }
            
            for query_data in queries:
                query = query_data['query']
                ground_truth = query_data.get('ground_truth', '')
                relevant_chunks = query_data.get('relevant_chunks', [])
                
                print(f'  Query: {query[:50]}...')
                
                start_time = time.time()
                result = query_rag(query=query, model_name=model_name, top_k=5)
                rag_latency = time.time() - start_time
                
                retrieval_scores = self.evaluate_retrieval(result['contexts'], relevant_chunks)
                for metric, value in retrieval_scores.items():
                    model_results['retrieval_metrics'][metric].append(value)
                
                answer_scores = self.evaluate_answer_quality(result['answer'], ground_truth)
                for metric, value in answer_scores.items():
                    model_results['answer_metrics'][metric].append(value)
                
                for lang_name in languages_to_test:
                    lang_code = Config.SUPPORTED_LANGUAGES[lang_name]
                    if lang_code == 'en':
                        continue
                    
                    trans_start = time.time()
                    translated = translate_answer(result['answer'], lang_code)
                    trans_latency = time.time() - trans_start
                    
                    trans_scores = self.evaluate_translation(result['answer'], translated)
                    trans_scores['latency_ms'] = trans_latency * 1000
                    
                    for metric, value in trans_scores.items():
                        model_results['translation_metrics'][lang_name][metric].append(value)
                
                model_results['latency'].append(rag_latency)
            
            aggregated = self.aggregate_metrics(model_results)
            all_results.append(aggregated)
            print(f'  Done: {model_name}')
        
        self.generate_all_tables(all_results)
        return all_results
    
    def aggregate_metrics(self, model_results):
        aggregated = {'model': model_results['model']}
        
        for metric, values in model_results['retrieval_metrics'].items():
            aggregated[f'{metric}_mean'] = np.mean(values)
        
        for metric, values in model_results['answer_metrics'].items():
            aggregated[f'{metric}_mean'] = np.mean(values)
        
        aggregated['translation'] = {}
        for lang, metrics in model_results['translation_metrics'].items():
            aggregated['translation'][lang] = {m: np.mean(v) for m, v in metrics.items()}
        
        aggregated['latency_p50'] = np.percentile(model_results['latency'], 50)
        aggregated['latency_p95'] = np.percentile(model_results['latency'], 95)
        
        return aggregated
    
    def generate_all_tables(self, results):
        output_dir = Path(Config.RESULTS_DIR) / 'tables'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        table1_data = []
        for res in results:
            table1_data.append({
                'Model': res['model'],
                'Recall@3': f"{res['recall@3_mean']:.3f}",
                'MRR': f"{res['mrr_mean']:.3f}",
                'EM': f"{res['exact_match_mean']:.3f}",
                'F1': f"{res['f1_mean']:.3f}",
                'ROUGE-L': f"{res['rouge_l_mean']:.3f}",
                'Latency_p50': f"{res['latency_p50']:.2f}",
                'Latency_p95': f"{res['latency_p95']:.2f}"
            })
        
        df1 = pd.DataFrame(table1_data)
        df1.to_csv(output_dir / 'table1_model_comparison.csv', index=False)
        print(f'\nTable 1 saved: {output_dir}/table1_model_comparison.csv')
        print(df1.to_string(index=False))
        
        table2_data = []
        for res in results:
            for lang, metrics in res.get('translation', {}).items():
                table2_data.append({
                    'Model': res['model'],
                    'Language': lang,
                    'Length_Ratio': f"{metrics.get('length_ratio', 0):.2f}",
                    'Citation_Preservation': f"{metrics.get('citation_preservation', 0):.2f}",
                    'Latency_ms': f"{metrics.get('latency_ms', 0):.0f}"
                })
        
        if table2_data:
            df2 = pd.DataFrame(table2_data)
            df2.to_csv(output_dir / 'table2_translation_quality.csv', index=False)
            print(f'\nTable 2 saved: {output_dir}/table2_translation_quality.csv')
        
        self.generate_latex_tables(results, output_dir)
        print(f'\nAll tables in: {output_dir}')

    def generate_latex_tables(self, results, output_dir):
        latex = [r'\begin{table}[h]', r'\centering', r'\caption{Model Performance Comparison}',
                r'\begin{tabular}{lcccccc}', r'\toprule',
                r'Model & Recall@3 & MRR & EM & F1 & ROUGE-L & Latency (s) \\', r'\midrule']
        
        for res in results:
            latex.append(
                f"{res['model']} & {res['recall@3_mean']:.3f} & {res['mrr_mean']:.3f} & "
                f"{res['exact_match_mean']:.3f} & {res['f1_mean']:.3f} & "
                f"{res['rouge_l_mean']:.3f} & {res['latency_p50']:.2f} \\\\"
            )
        
        latex.extend([r'\bottomrule', r'\end{tabular}', r'\end{table}'])
        
        with open(output_dir / 'latex_tables.tex', 'w') as f:
            f.write('\n'.join(latex))
        print(f'LaTeX saved: {output_dir}/latex_tables.tex')

if __name__ == '__main__':
    evaluator = RAGEvaluator()
    
    queries_file = 'data/queries/benchmark_queries.json'
    
    models_to_test = [
        'llama-3.1-8b-instant',
        'llama-3.3-70b-versatile',
        'qwen/qwen3-32b'
    ]
    
    languages_to_test = ['English', 'Hindi / हनद', 'Tamil / தமழ', 'Telugu / తలగ', 
                        'Kannada / ಕನನಡ', 'Malayalam / മലയള']
    
    results = evaluator.run_benchmark(queries_file, models_to_test, languages_to_test)
    print('\nBENCHMARK COMPLETE!')