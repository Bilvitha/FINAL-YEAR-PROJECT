﻿'''
Complete ingestion pipeline for batch processing
'''
from pathlib import Path
from src.utils.config import Config
from src.ingest.partition_document import partition_document
from src.ingest.chunk_documents import create_chunks_by_title
from src.ingest.summarize_chunks import summarize_chunks
from src.embeddings.embed_and_index import embed_chunks, create_vector_store

def process_document(pdf_path: str):
    '''Run complete pipeline on a single document'''
    print(f'\n{'='*50}')
    print(f'Processing: {pdf_path}')
    print(f'{'='*50}\n')
    
    # Step 1: Partition
    elements = partition_document(pdf_path)
    
    # Step 2: Chunk
    chunks = create_chunks_by_title(elements)
    
    # Step 3: Summarize
    processed_chunks = summarize_chunks(chunks)
    
    # Step 4: Embed
    embeddings = embed_chunks(processed_chunks)
    
    # Step 5: Index
    source_name = Path(pdf_path).name
    collection = create_vector_store(processed_chunks, embeddings, source_name)
    
    print(f'\n Successfully processed: {source_name}')
    return collection

def process_all_documents():
    '''Process all PDFs in data/raw/pdfs'''
    pdf_dir = Path(Config.DATA_RAW_DIR) / 'pdfs'
    pdf_files = list(pdf_dir.glob('*.pdf'))
    
    if not pdf_files:
        print(f' No PDF files found in {pdf_dir}')
        print('Please place your PDF files in data/raw/pdfs/')
        return
    
    print(f'\nFound {len(pdf_files)} PDF files to process')
    
    for pdf_file in pdf_files:
        try:
            process_document(str(pdf_file))
        except Exception as e:
            print(f' Error processing {pdf_file.name}: {e}')
            continue
    
    print(f'\n Pipeline completed! Processed {len(pdf_files)} documents')

if __name__ == '__main__':
    process_all_documents()
