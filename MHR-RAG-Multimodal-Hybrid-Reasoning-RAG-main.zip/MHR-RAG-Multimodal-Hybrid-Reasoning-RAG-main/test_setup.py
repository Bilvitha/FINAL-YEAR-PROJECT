﻿from groq import Groq
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv
import os

load_dotenv()

# Test Groq with CURRENT model
print('Testing Groq API with current models...')
client = Groq(api_key=os.getenv('GROQ_API_KEY'))
response = client.chat.completions.create(
    model='llama-3.1-8b-instant',  # UPDATED: Current model
    messages=[{'role': 'user', 'content': 'Say hello in 5 words'}],
    max_tokens=50
)
print(f' Groq response: {response.choices[0].message.content}')

# Test embeddings
print('\nTesting embeddings...')
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
embedding = model.encode(['Test sentence'])
print(f' Embedding shape: {embedding.shape}')

# Test ChromaDB
print('\nTesting ChromaDB...')
import chromadb
client = chromadb.PersistentClient(path='./dbv1/chroma_db')
print(f' ChromaDB initialized at: ./dbv1/chroma_db')

print('\n All tests passed! Ready to run app.py')
