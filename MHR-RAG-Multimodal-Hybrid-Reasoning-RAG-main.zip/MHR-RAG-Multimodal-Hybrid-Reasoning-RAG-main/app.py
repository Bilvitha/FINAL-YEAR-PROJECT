﻿import streamlit as st
import os
from pathlib import Path
from src.utils.config import Config
from src.ingest.partition_document import partition_document
from src.ingest.chunk_documents import create_chunks_by_title
from src.ingest.summarize_chunks import summarize_chunks
from src.ingest.transcribe_audio import transcribe_audio_file, format_timestamp
from src.embeddings.embed_and_index import embed_chunks, create_vector_store
from src.retrieval.query_rag import query_rag
from src.translation.translate import translate_answer

# Page config
st.set_page_config(
    page_title='MHR-RAG: Multimodal Hybrid Reasoning RAG',
    page_icon='',
    layout='wide'
)

# Title
st.title(' MHR-RAG: Multimodal Hybrid Reasoning RAG')
st.markdown('**Multimodal Document Processing with Multilingual Output (22 Indian Languages)**')

# Sidebar
with st.sidebar:
    st.header(' Configuration')
    
    # Model selection
    selected_model = st.selectbox(
        'LLM Model',
        Config.AVAILABLE_LLMS,
        index=1  # Default to llama-3.3-70b-versatile
    )
    
    # Language selection (ALL 22 LANGUAGES)
    output_language = st.selectbox(
        'Output Language / आउटपट भष',
        list(Config.SUPPORTED_LANGUAGES.keys())
    )
    
    # Top-K retrieval
    top_k = st.slider('Top-K Retrieval', 1, 10, 5)
    
    st.markdown('---')
    st.markdown('###  System Status')
    st.success(' Groq API Connected')
    st.success(' Embeddings Loaded')
    st.success(' 22 Languages Supported')
    st.info(f' ChromaDB: {Config.CHROMA_PERSIST_DIR}')

# Main content
tab1, tab2, tab3 = st.tabs([' Document Ingestion', ' Audio Processing', ' Query & Retrieve'])

# Tab 1: Document Ingestion
with tab1:
    st.header(' Upload & Process Documents')
    
    uploaded_file = st.file_uploader(
        'Upload PDF Document',
        type=['pdf'],
        help='Upload research papers, textbooks, or any PDF with text, tables, and images'
    )
    
    if uploaded_file is not None:
        save_path = Path(Config.DATA_RAW_DIR) / 'pdfs' / uploaded_file.name
        save_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(save_path, 'wb') as f:
            f.write(uploaded_file.getbuffer())
        
        st.success(f' File saved: {save_path}')
        
        if st.button(' Process Document', type='primary'):
            with st.spinner('Processing document...'):
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                status_text.text(' Partitioning document...')
                elements = partition_document(str(save_path))
                progress_bar.progress(20)
                
                status_text.text(' Creating chunks...')
                chunks = create_chunks_by_title(elements)
                progress_bar.progress(40)
                
                status_text.text(' Generating summaries...')
                processed_chunks = summarize_chunks(chunks)
                progress_bar.progress(60)
                
                status_text.text(' Creating embeddings...')
                embeddings = embed_chunks(processed_chunks)
                progress_bar.progress(80)
                
                status_text.text(' Indexing into ChromaDB...')
                collection = create_vector_store(
                    processed_chunks,
                    embeddings,
                    uploaded_file.name
                )
                progress_bar.progress(100)
                
                status_text.text(' Processing complete!')
                
                col1, col2, col3, col4 = st.columns(4)
                col1.metric('Elements', len(elements))
                col2.metric('Chunks', len(chunks))
                col3.metric('Embeddings', len(embeddings))
                col4.metric('Indexed', len(processed_chunks))
                
                st.balloons()

# Tab 2: Audio Processing (NEW!)
with tab2:
    st.header(' Upload & Transcribe Audio')
    st.markdown('Upload lecture recordings, podcasts, or audio interviews')
    
    audio_file = st.file_uploader(
        'Upload Audio File',
        type=['mp3', 'wav', 'm4a', 'ogg', 'flac', 'aac'],
        help='Supports MP3, WAV, M4A, OGG, FLAC, AAC formats (max 25MB per file)'
    )
    
    if audio_file is not None:
        save_path = Path(Config.DATA_RAW_DIR) / 'audio' / audio_file.name
        save_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(save_path, 'wb') as f:
            f.write(audio_file.getbuffer())
        
        st.success(f' Audio saved: {save_path}')
        st.audio(str(save_path))
        
        if st.button(' Transcribe & Process', type='primary', key='audio_process'):
            with st.spinner('Transcribing audio...'):
                # Transcribe
                transcription = transcribe_audio_file(str(save_path))
                
                st.success(f' Transcribed {transcription["duration"]:.1f} seconds')
                
                # Display transcript with timestamps
                st.markdown('###  Transcript with Timestamps')
                for seg in transcription['segments']:
                    timestamp = format_timestamp(seg['start'])
                    st.markdown(f'**[{timestamp}]** {seg["text"]}')
                
                # Process into ChromaDB
                with st.spinner('Processing into vector database...'):
                    # Create chunks from audio segments
                    audio_chunks = []
                    for i, seg in enumerate(transcription['segments']):
                        audio_chunks.append({
                            'chunk_id': i,
                            'short_summary': seg['text'][:150],
                            'long_summary': seg['text'],
                            'raw_text': seg['text'],
                            'tables_html': [],
                            'image_count': 0,
                            'modality_types': ['audio'],
                            'audio_timestamp': f"{format_timestamp(seg['start'])} - {format_timestamp(seg['end'])}"
                        })
                    
                    # Embed and index
                    embeddings = embed_chunks(audio_chunks)
                    collection = create_vector_store(
                        audio_chunks,
                        embeddings,
                        f"audio_{audio_file.name}"
                    )
                    
                    st.success(f' Indexed {len(audio_chunks)} audio segments')
                    st.balloons()

# Tab 3: Query & Retrieve
with tab3:
    st.header(' Query Documents & Audio')
    
    query = st.text_area(
        'Enter your question:',
        placeholder='What is the Transformer architecture?\nAt 5:30 in the lecture, what concept is explained?',
        height=100
    )
    
    if st.button(' Search & Generate Answer', type='primary'):
        if not query:
            st.warning(' Please enter a question')
        else:
            with st.spinner('Searching and generating answer...'):
                result = query_rag(
                    query=query,
                    model_name=selected_model,
                    top_k=top_k
                )
                
                # Translate if needed
                lang_code = Config.SUPPORTED_LANGUAGES[output_language]
                if lang_code != 'en':
                    with st.spinner(f'Translating to {output_language}...'):
                        translated_answer = translate_answer(
                            result['answer'],
                            lang_code
                        )
                        final_answer = translated_answer
                else:
                    final_answer = result['answer']
                
                # Display answer
                st.markdown('###  Answer')
                st.markdown(f'**Language:** {output_language}')
                st.markdown(f'**Model:** {result["model"]}')
                st.success(final_answer)
                
                # Display original English if translated
                if lang_code != 'en':
                    with st.expander(' Original English Answer'):
                        st.write(result['answer'])
                
                # Display sources
                st.markdown('###  Retrieved Sources')
                for i, context in enumerate(result['contexts'], 1):
                    with st.expander(f'Source [{i}]'):
                        st.code(context, language='text')
